#ifndef IOT_H
#define IOT_H

#ifdef __cplusplus
extern "C" {
#endif

int add(int x, int y);

#ifdef __cplusplus
}
#endif
#endif // IOT_H