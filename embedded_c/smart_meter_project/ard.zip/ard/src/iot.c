#include <iot.h>

int add(int x, int y) {
    b = x+y;
    print (b);
}